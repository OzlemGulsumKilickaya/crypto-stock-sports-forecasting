import pandas as pd
from binance.client import Client
import datetime

client = Client()

symbol = 'SOLUSDT'
interval = Client.KLINE_INTERVAL_1HOUR

start_str = '1 Jan, 2024'
end_str = datetime.datetime.now().strftime('%d %b, %Y')

klines = client.get_historical_klines(symbol, interval, start_str, end_str)

columns = ['Open Time', 'Open', 'High', 'Low', 'Close', 'Volume',
           'Close Time', 'Quote Asset Volume', 'Number of Trades',
           'Taker Buy Base Volume', 'Taker Buy Quote Volume', 'Ignore']

df = pd.DataFrame(klines, columns=columns)

df['Open Time'] = pd.to_datetime(df['Open Time'], unit='ms')
df['Close Time'] = pd.to_datetime(df['Close Time'], unit='ms')

df = df[['Open Time', 'Open', 'High', 'Low', 'Close', 'Volume']]

df.to_csv('solana_hourly.csv', index=False)

print("✅ solana_hourly.csv created successfully!")
